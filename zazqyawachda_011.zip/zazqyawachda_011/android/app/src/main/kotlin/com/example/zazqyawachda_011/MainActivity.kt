package com.example.zazqyawachda_011

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
